package springapp;

public interface ArticleDao {

	void insert(Article article);

}

package springapp;

public interface WriteArticleService {

	public void write(Article article);
}

package springapp;

public class Article {
	Article(){
		System.out.println("<Article> ����");
	}
}

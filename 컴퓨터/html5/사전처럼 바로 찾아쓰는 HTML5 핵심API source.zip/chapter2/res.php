<?
 echo "좋아하는 단어:".$_POST['q1']."</br>";
 echo "싫어하는:".$_POST['q2']."</br>";
 echo "닉네임:".$_POST['q3']."</br>";
?>